import java.io.IOException;

public class App {

	public static void main(String[] args) {
        AnotacionPersonalizada obj = new AnotacionPersonalizada();

        try {
            
            obj.serializeToJson();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
