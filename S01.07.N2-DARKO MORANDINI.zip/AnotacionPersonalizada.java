import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

// Definición de la anotación personalizada
@Target(ElementType.TYPE)
@interface SerializeToJson {
    String directory();
}

@SerializeToJson(directory = "/Users/darkomorandini/eclipse/ARCHIVOS EXT")
class AnotacionPersonalizada {

    public AnotacionPersonalizada() {
    
    }

	// Método para serializar el objeto en JSON y guardarlo en el archivo correspondiente
    public void serializeToJson() throws IOException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String json = gson.toJson(this);

        String directory = getClass().getAnnotation(SerializeToJson.class).directory();
        String filePath = directory + "/" + getClass().getSimpleName() + ".json";

        try (FileWriter writer = new FileWriter(filePath)) {
			writer.write(json);
		}    
    }
}